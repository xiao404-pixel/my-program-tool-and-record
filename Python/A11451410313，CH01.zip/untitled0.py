#A114510313 江惠宇

t,w = eval(input("請輸入身高(cm)、體重(kg)，輸入值以逗號隔開:".split(',')))
          
print ("BMI=""%.2f"%(w/(t/100)**2))